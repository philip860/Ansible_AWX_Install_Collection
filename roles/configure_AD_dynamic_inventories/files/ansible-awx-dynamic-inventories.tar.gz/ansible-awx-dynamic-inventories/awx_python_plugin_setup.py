import os.path
import subprocess
from getpass import getpass

#Path of AWX Ansible Plugin Location
path = "/opt/awx/its-plugins"

Directory_Exists = os.path.isdir(path)

if Directory_Exists == False:

    print("Directory Does Not Exist" + "\n")

    #We will now make the Directory
    subprocess.check_output(['mkdir -p /opt/awx/its-plugins'], shell=True, universal_newlines=True)
else:
     print("Directory Detected" + "\n")

#We now need to Download the needed files from our git repo
subprocess.check_output(['cd /opt/awx/its-plugins  && git clone https://bitbucket.uconn.edu/scm/awx-its/ansible-awx-dynamic-inventories.git'], shell=True, universal_newlines=True)

#Now we need to check if our system has a valid crt certification needed to successfully run the plugin
#We will check the /etc/pki directory to see if one is present

#We need to get the short hostname
#This will be used to dynamically track
#down the crt name for our systems
Short_Hostname_var = str(subprocess.getoutput("hostname -s"))


crt_path = (f"/etc/pki/tls/certs/{Short_Hostname_var}.grove.ad.uconn.edu.crt")


if os.path.exists(crt_path):

    print("crt file detected" + "\n")
    #Now we can copy our crt file to our /opt/awx/its-plugins directory
    #subprocess.check_output([f"cp -r {crt_path}  /opt/awx/its-plugins/ansible-awx-dynamic-inventories/{Short_Hostname_var}.grove.ad.uconn.edu.crt"], shell=True, universal_newlines=True)


else:

    print("crt file not detected please run certfiable install to configure one")

    #We will download the repo that has the cerfiable installer
    subprocess.check_output(['mkdir -p /opt/awx/its-plugins/tmp && mkdir -p /ITS_tools && git clone https://bitbucket.uconn.edu/scm/awx-its/its-awx-server-build.git'], shell=True, universal_newlines=True)

    subprocess.check_output(['/bin/sleep 20'], shell=True, universal_newlines=True)

    # Now we can copy our crt file to our /opt/awx/its-plugins directory
    subprocess.check_output([f"cp -r {crt_path}  /opt/awx/its-plugins/ansible-awx-dynamic-inventories/"], shell=True, universal_newlines=True)


#Now we need to edit our ldap-ad.ini file
#We need to enter the AD OU domain bind creds
#As well as the OU we want to use for the AWX Inventory

netid_var = input('Enter your netID Admin account: ')

#We will use getpass module to hide user netID password
#getpass has an issue displaying in some IDE development tools
#Will use regualr input command to enter creds for now
#netid_password_var = getpass('Enter your netID Admin password: ')
netid_password_var = input('Enter your netID Admin password: ')

ad_ou_var = input('Enter the dn for the AD OU you wish to use for an inventory: ')

#Now we need to take the values from these inputs and populate them into our
#//opt/awx/its-plugins/ansible-awx-dynamic-inventories/ldap-ad.ini file

#We need to get the input of the ldap-ad.ini file
fin = open("/opt/awx/its-plugins/ansible-awx-dynamic-inventories/ldap-ad.ini", "rt")
# output of the new file that will to write the result to
fout = open("/opt/awx/its-plugins/ansible-awx-dynamic-inventories/ldap-ad-temp1.ini", "wt")

# for loop to navigate each line in the input file
#This for loop will replace the net-id place holder in the ldap-ad-temp1.ini file
for line in fin:

  # read replace the string and write to output file
  fout.write(line.replace('net-id', netid_var))
fout.close()


#We need to get the input of the ldap-ad-temp1.ini file
fin2 = open("/opt/awx/its-plugins/ansible-awx-dynamic-inventories/ldap-ad-temp1.ini", "rt")
# output of the new file that will to write the result to
fout2 = open("/opt/awx/its-plugins/ansible-awx-dynamic-inventories/ldap-ad-temp2.ini", "wt")

# for loop to navigate each line in the input file
#This for loop will replace the ad-creds place holder in the ldap-ad-temp1.ini file
for line in fin2:

  # read replace the string and write to output file
  fout2.write(line.replace('ad-creds', netid_password_var))
fout2.close()

#We need to get the input of the ldap-ad-temp1.ini file
fin3 = open("/opt/awx/its-plugins/ansible-awx-dynamic-inventories/ldap-ad-temp2.ini", "rt")
# output of the new file that will to write the result to
fout3 = open("/opt/awx/its-plugins/ansible-awx-dynamic-inventories/ldap-ad-temp3.ini", "wt")

# for loop to navigate each line in the input file
#This for loop will replace the its-ad-ou place holder in the ldap-ad-temp1.ini file
for line in fin3:

  # read replace the string and write to output file
  fout3.write(line.replace('its-ad-ou', ad_ou_var))
fout3.close()


#We need to get the input of the ldap-ad-temp1.ini file
fin4 = open("/opt/awx/its-plugins/ansible-awx-dynamic-inventories/ldap-ad-temp3.ini", "rt")
# output of the new file that will to write the result to
fout4 = open("/opt/awx/its-plugins/ansible-awx-dynamic-inventories/ldap-ad-temp4.ini", "wt")

# for loop to navigate each line in the input file
#This for loop will replace the its-ad-ou place holder in the ldap-ad-temp1.ini file
for line in fin4:

  # read replace the string and write to output file
  fout4.write(line.replace('hostname-crt', f'{Short_Hostname_var}.grove.ad.uconn.edu.crt'))
fout4.close()



#Now we need to replace the default ldap-ad-ini file with the ldap-ad-temp3.ini one
#First we rename the ldap-ad.ini file to ldap-ad-default.ini
subprocess.check_output([f" mv /opt/awx/its-plugins/ansible-awx-dynamic-inventories/ldap-ad.ini  /opt/awx/its-plugins/ansible-awx-dynamic-inventories/ldap-ad-default.ini"], shell=True,
                        universal_newlines=True)

#Next we will copy over our ldap-ad.ini
subprocess.check_output([f" cp -r  /opt/awx/its-plugins/ansible-awx-dynamic-inventories/ldap-ad-temp4.ini  /opt/awx/its-plugins/ansible-awx-dynamic-inventories/ldap-ad.ini"], shell=True,
                        universal_newlines=True)

#We will clean up the opt/awx/its-plugins/ansible-awx-dynamic-inventories/ directory
# by removing the temp ldap-ad.ini files

subprocess.check_output([f" cd /opt/awx/its-plugins/ansible-awx-dynamic-inventories/ && rm -rf ldap-ad-temp1.ini ldap-ad-temp2.ini  ldap-ad-temp3.ini ldap-ad-temp4.ini"], shell=True,
                       universal_newlines=True)

#We will create an inventory directory for all of our future inventories moving forward
#We will use the input entered previously to create an example inventory to use for
#first setup
subprocess.check_output([f" mkdir -p  /opt/awx/inventories/ITS-Demo-Inventory && cp -r /opt/awx/its-plugins/ansible-awx-dynamic-inventories/ldap-ad.ini  /opt/awx/inventories/ITS-Demo-Inventory"], shell=True,
                       universal_newlines=True)


#We now need info on the AWX Server's inventory we will be updating
#If you already haven't create a new inventory in the AWX server's UI
#Next saved the ID number of the newly or previously created inventory

#netid_password_var = getpass('Enter your netID Admin password: ')
awx_inventory_id_var = input("Enter your inventory's unique ID: ")

awx_username_var = input('Enter the AWX service account you wish to use for login: ')

awx_password_var = input('Enter the AWX service account password: ')



#We need to get the input of the add_hosts_to_a_inventory.pyfile
fin5 = open("/opt/awx/its-plugins/ansible-awx-dynamic-inventories/api/add_hosts_to_a_inventory.py", "rt")
# output of the new file that will to write the result to
fout5 = open("/opt/awx/its-plugins/ansible-awx-dynamic-inventories/api/add_hosts_to_a_inventory-temp1.py", "wt")

# for loop to navigate each line in the input file
#This for loop will replace the ID-Number place holder in the add_hosts_to_a_inventory-temp1.py file
for line in fin5:

  # read replace the string and write to output file
  fout5.write(line.replace('ID-Number', f'{awx_inventory_id_var }'))
fout5.close()


#We need to get the input of the add_hosts_to_a_inventory.pyfile
fin6 = open("/opt/awx/its-plugins/ansible-awx-dynamic-inventories/api/add_hosts_to_a_inventory-temp1.py", "rt")
# output of the new file that will to write the result to
fout6 = open("/opt/awx/its-plugins/ansible-awx-dynamic-inventories/api/add_hosts_to_a_inventory-temp2.py", "wt")

# for loop to navigate each line in the input file
#This for loop will replace the admin-user placeholder in the add_hosts_to_a_inventory-temp2.py file
for line in fin6:

  # read replace the string and write to output file
  fout6.write(line.replace('admin-user', f'{awx_username_var}'))
fout6.close()


#We need to get the input of the add_hosts_to_a_inventory.pyfile
fin7 = open("/opt/awx/its-plugins/ansible-awx-dynamic-inventories/api/add_hosts_to_a_inventory-temp2.py", "rt")
# output of the new file that will to write the result to
fout7 = open("/opt/awx/its-plugins/ansible-awx-dynamic-inventories/api/add_hosts_to_a_inventory-temp3.py", "wt")

# for loop to navigate each line in the input file
#This for loop will replace the password placeholder in the add_hosts_to_a_inventory-temp3.py file
for line in fin7:

  # read replace the string and write to output file
  fout7.write(line.replace('password', f'{awx_password_var}'))
fout7.close()


#We need to get the input of the add_hosts_to_a_inventory.pyfile
fin8 = open("/opt/awx/its-plugins/ansible-awx-dynamic-inventories/api/add_hosts_to_a_inventory-temp3.py", "rt")
# output of the new file that will to write the result to
fout8 = open("/opt/awx/its-plugins/ansible-awx-dynamic-inventories/api/add_hosts_to_a_inventory-temp4.py", "wt")

# for loop to navigate each line in the input file
#This for loop will replace the hostname placeholder in the add_hosts_to_a_inventory-temp3.py file
for line in fin8:

  # read replace the string and write to output file
  fout8.write(line.replace('HOSTNAME', f'{Short_Hostname_var}.grove.ad.uconn.edu'))
fout8.close()

#Now we copy the last temp add_hosts_to_a_inventory.py files
#Saving it as our orginal one
subprocess.check_output([f" cp -r /opt/awx/its-plugins/ansible-awx-dynamic-inventories/api/add_hosts_to_a_inventory-temp4.py  /opt/awx/its-plugins/ansible-awx-dynamic-inventories/api/add_hosts_to_a_inventory.py"], shell=True,
                        universal_newlines=True)

#Now we will remove the temp add_hosts_to_a_inventory.py files
subprocess.check_output([f" cd /opt/awx/its-plugins/ansible-awx-dynamic-inventories/api/ && rm -rf  add_hosts_to_a_inventory-temp1.py add_hosts_to_a_inventory-temp2.py add_hosts_to_a_inventory-temp3.py add_hosts_to_a_inventory-temp4.py add_hosts_to_a_inventory-temp5.py"]
                        , shell=True,
                        universal_newlines=True)

#We need to get the input of the custom_add_hosts_to_a_inventory.py file
fin9 = open("/opt/awx/its-plugins/ansible-awx-dynamic-inventories/api/cronjob/custom_add_hosts_to_a_inventory.py", "rt")
# output of the new file that will to write the result to
fout9 = open("/opt/awx/its-plugins/ansible-awx-dynamic-inventories/api/cronjob/custom_add_hosts_to_a_inventory-1.py", "wt")

# for loop to navigate each line in the input file
#This for loop will replace the hostname placeholder in the add_hosts_to_a_inventory-temp3.py file
for line in fin9:
  # read replace the string and write to output file
  fout9.write(line.replace('HOSTNAME', f'{Short_Hostname_var}.grove.ad.uconn.edu'))
fout9.close()




#We need to get the input of the custom_add_hosts_to_a_inventory.py file
fin10= open("/opt/awx/its-plugins/ansible-awx-dynamic-inventories/api/cronjob/custom_add_hosts_to_a_inventory-1.py", "rt")
# output of the new file that will to write the result to
fout10 = open("/opt/awx/its-plugins/ansible-awx-dynamic-inventories/api/cronjob/custom_add_hosts_to_a_inventory-2.py", "wt")

# for loop to navigate each line in the input file
#This for loop will replace the admin-user placeholder in the custom_add_hosts_to_a_inventory file
for line in fin10:
  # read replace the string and write to output file
  fout10.write(line.replace('admin-user', f'{awx_username_var}'))
fout10.close()


#We need to get the input of the custom_add_hosts_to_a_inventory.py file
fin11 = open("/opt/awx/its-plugins/ansible-awx-dynamic-inventories/api/cronjob/custom_add_hosts_to_a_inventory-2.py", "rt")
# output of the new file that will to write the result to
fout11 = open("/opt/awx/its-plugins/ansible-awx-dynamic-inventories/api/cronjob/custom_add_hosts_to_a_inventory-3.py", "wt")

# for loop to navigate each line in the input file
#This for loop will replace the password placeholder in the custom_add_hosts_to_a_inventory file
for line in fin11:
  # read replace the string and write to output file
  fout11.write(line.replace('password', f'{awx_password_var}'))
fout11.close()



#Now we copy the last temp custom_add_hosts_to_a_inventory.py files
#Saving it as our orginal one
subprocess.check_output([f" cp -r /opt/awx/its-plugins/ansible-awx-dynamic-inventories/api/cronjob/custom_add_hosts_to_a_inventory-3.py  /opt/awx/its-plugins/ansible-awx-dynamic-inventories/api/cronjob/custom_add_hosts_to_a_inventory.py"], shell=True,
                        universal_newlines=True)

#Now we will remove the temp custom_add_hosts_to_a_inventory.py
subprocess.check_output([f" cd /opt/awx/its-plugins/ansible-awx-dynamic-inventories/api/cronjob/ && rm -rf custom_add_hosts_to_a_inventory-1.py custom_add_hosts_to_a_inventory-2.py custom_add_hosts_to_a_inventory-3.py"], shell=True,
                        universal_newlines=True)


#Now we need to copy the get ad hosts file over
#Saving it as our orginal one
subprocess.check_output([f" cp -r /opt/awx/its-plugins/ansible-awx-dynamic-inventories/api/get_ad_ou_hosts.py /opt/awx/its-plugins/ansible-awx-dynamic-inventories/api/cronjob/get_ad_ou_hosts.py"], shell=True,
                        universal_newlines=True)