import requests
import json
from get_ad_ou_hosts import get_ad_hosts_json_output_var
from get_ad_ou_hosts import nested_ou_var

from requests.auth import HTTPBasicAuth
headers = {'content-type': 'application/json'}


#We need to open our temporary json file
#f = open("test_inventory.json")

#print(get_ad_hosts_json_output_var)

#We will take the variable from our get ad OU hosts script
#An load the data for us to upload to AWX
data = json.loads(get_ad_hosts_json_output_var)


#Empty List that our cleaned up json file values will be stored in
json_item_list_parsed = []

count = 0

#This for loop is used to get the nested json file's
#hostnames for each indices
for item in data[f"{nested_ou_var}"]['hosts']:

    #use the item index indices to get all the characters of each corresponding hostname
    json_parsed = (item[0:100])

    #Appened parsed values to clean lists
    json_item_list_parsed.append(json_parsed)

# counter variable
i = 0


#Here we will add the first hostname we got in our parsed list
first_host_element_in_list = json_item_list_parsed[i]

data_first_host = {'name': first_host_element_in_list}

#We will send a request command to our
requests.post('https://ansible-msb-0.grove.ad.uconn.edu/api/v2/inventories/2/hosts/',
                            verify=False, auth=HTTPBasicAuth('iam.awx.svc', 'ZTYxZDNhZDMzY2JhMmVjOWQ1Yjc0YmFl'), data=json.dumps(data_first_host),
                            headers=headers)



#This for loop will now use the length of our list
#to enter in our hostnames contained in the list
#the loop will start at element 2 of the json_item_list_parsed list
#next the list will enter in the hostname into the request.post command
#this will then add our hostnames to the awx server
for i in range(len(json_item_list_parsed)):

    if i < len(json_item_list_parsed) - 1:

        #Variable used to stored the iteriated hostnames
        new_hosts = json_item_list_parsed[i + 1]

        data_new = {'name': new_hosts}

        res = requests.post('https://ansible-msb-0.grove.ad.uconn.edu/api/v2/inventories/2/hosts/',
                            verify=False, auth=HTTPBasicAuth('iam.awx.svc', 'ZTYxZDNhZDMzY2JhMmVjOWQ1Yjc0YmFl'), data=json.dumps(data_new),
                            headers=headers)
        print(res.content)
        #print(data)

        #print('next', json_item_list_parsed[i + 1])

    else:

        # end
        print('this', json_item_list_parsed[i])

