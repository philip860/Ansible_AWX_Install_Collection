#!/usr/bin/python
# -*- coding: utf-8 -*-

#This script will use AD information to pull current hosts in a specific OU.
#Script will take input from user on what the inventory-ID is
#As well as the source of the AD OU information directory 
#Lastly script will import gather AD hosts into AWX Inventory

#Example ( python3 custom_add_hosts_to_a_inventory.py --inventory "5" --source "/opt/awx/inventories/ITS-IAM" )

import subprocess
import linecache
import requests
import json
import argparse
import ssl
import configparser

from requests.auth import HTTPBasicAuth
headers = {'content-type': 'application/json'}

#Here we will take command line inputs
#This is needed to dynamically change
#The inventory ID & source directory
parser = argparse.ArgumentParser(
    description='Script to add AD OU into inventory')
parser.add_argument('--inventory', type=str)
parser.add_argument('--source',  type=str)

#Global Variables
source = ""
inventory = ""

args = parser.parse_args()

#We will set variables in order to store our parsed terminal command inputs
#These variables will be used later
source_var = args.source
inventory_var = args.inventory


#Create String to pass json info to
get_ad_hosts_json_output_var = str(subprocess.check_output([f'python3 /opt/awx/its-plugins/ansible-awx-dynamic-inventories/ldap-ad.py --path {source_var} --list'],
                                                           shell=True, universal_newlines=True))

#Generate json temp file that will store the AD OU's hosts & name
subprocess.check_output([f'python3 /opt/awx/its-plugins/ansible-awx-dynamic-inventories/ldap-ad.py --path {source_var}  --list > {source_var}/ad-ou-hosts.json'],
                                                           shell=True, universal_newlines=True)


#We will sleep while we let our processes finish
#subprocess.check_output(['/bin/sleep 20'],  shell=True, universal_newlines=True)




#Extract the line in the json file that contains the OU's Name
#We will saved the extracted value in a variable that will be used
#to loop through the nested json file values
json_file_ou_var = linecache.getline(f'{source_var}/ad-ou-hosts.json', 5)


#Here we will edit our json file so the final output is just the data we need
json_file_ou_string1_var = json_file_ou_var.replace('"', "")
json_file_ou_string2_var = json_file_ou_string1_var.replace(':', "")
json_file_ou_string3_var = json_file_ou_string2_var.replace('{', "")
json_file_ou_string4_var = json_file_ou_string3_var.replace(' ', "")
json_file_ou_string5_var = json_file_ou_string4_var.strip()

#We will use a easier variable to identify our cleaned up json file output
#This variable will be used later on in the script
nested_ou_var = json_file_ou_string5_var

#### Now that we got our AD Host info we will add the hosts to AWX Inventory Below ######


#We will take the variable from our get ad OU hosts script
#An load the data for us to upload to AWX
data = json.loads(get_ad_hosts_json_output_var)


#Empty List that our cleaned up json file values will be stored in
json_item_list_parsed = []

count = 0

#This for loop is used to get the nested json file's
#hostnames for each indices
for item in data[f"{nested_ou_var}"]['hosts']:

    #use the item index indices to get all the characters of each corresponding hostname
    json_parsed = (item[0:100])

    #Appened parsed values to clean lists
    json_item_list_parsed.append(json_parsed)

# counter variable
i = 0


#Here we will add the first hostname we got in our parsed list
first_host_element_in_list = json_item_list_parsed[i]

data_first_host = {'name': first_host_element_in_list}

#We will send a request command to our
requests.post(f'https://awx-server-hostname/api/v2/inventories/{inventory_var}/hosts/',
                            verify=True, auth=HTTPBasicAuth('awx-admin-user', 'password'), data=json.dumps(data_first_host),
                            headers=headers, allow_redirects=True, timeout=5)



#This for loop will now use the length of our list
#to enter in our hostnames contained in the list
#the loop will start at element 2 of the json_item_list_parsed list
#next the list will enter in the hostname into the request.post command
#this will then add our hostnames to the awx server
for i in range(len(json_item_list_parsed)):

    if i < len(json_item_list_parsed) - 1:

        #Variable used to stored the iteriated hostnames
        new_hosts = json_item_list_parsed[i + 1]

        data_new = {'name': new_hosts}

        res = requests.post(f'https://awx-server-hostname/api/v2/inventories/{inventory_var}/hosts/',
                            verify=True, auth=HTTPBasicAuth('awx-admin-user', 'password'), data=json.dumps(data_new),
                            headers=headers, timeout=5)
        print(res.content)
        #print(data)

        #print('next', json_item_list_parsed[i + 1])

    else:

        # end
        print('this', json_item_list_parsed[i])


