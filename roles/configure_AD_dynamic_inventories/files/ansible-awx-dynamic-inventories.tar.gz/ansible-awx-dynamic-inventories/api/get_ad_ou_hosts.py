import subprocess
import linecache

#Create String to pass json info to
get_ad_hosts_json_output_var = str(subprocess.check_output(['python3 /opt/awx/its-plugins/ansible-awx-dynamic-inventories/ldap-ad.py --path "/opt/awx/inventories/ITS-Demo-Inventory" --list'],
                                                           shell=True, universal_newlines=True))

#Generate json temp file
subprocess.check_output(['python3 /opt/awx/its-plugins/ansible-awx-dynamic-inventories/ldap-ad.py --path "/opt/awx/inventories/ITS-Demo-Inventory" --list > /opt/awx/inventories/ITS-Demo-Inventory/ad-ou-hosts.json'],
                                                           shell=True, universal_newlines=True)



json_file_ou_var = linecache.getline('/opt/awx/inventories/ITS-Demo-Inventory/ad-ou-hosts.json', 5)

#print(json_file_ou_var)

json_file_ou_string1_var = json_file_ou_var.replace('"', "")

json_file_ou_string2_var = json_file_ou_string1_var.replace(':', "")

json_file_ou_string3_var = json_file_ou_string2_var.replace('{', "")

json_file_ou_string4_var = json_file_ou_string3_var.replace(' ', "")

json_file_ou_string5_var = json_file_ou_string4_var.strip()


nested_ou_var = json_file_ou_string5_var
