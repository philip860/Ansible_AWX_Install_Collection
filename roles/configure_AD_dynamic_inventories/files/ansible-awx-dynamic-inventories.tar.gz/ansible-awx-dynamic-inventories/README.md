
Dynamic Inventory For Ansible AWX Server
===============================================

#### Key Tips!
``` {.wp-block-code}
This repo will allow for the ability to connect to an AD OU an populate the hosts in AD, into the corresponding Inventory in AWX.

The Inventory in AWX will be updated automatically using AWX's scheduling abilites.

```

### Files Needed
``` {.wp-block-code}
ldap3 module for python

ldap.ini - configuration files

ldap.py - python files

AWX server's crt file

```

### Configuration of AWX Dynamic Inventory 

Step 1: Login To AWX Server GUI
--------------------------

``` 
#Navigate to https://hostname.grove.ad.uconn.edu/#/login to login to awx server

```

Step 2: Create Bitbucket Source Credentials
-----------------------------------------

``` {.wp-block-code}
#Select Credentials

#Add

#Fill out Name

#Credential Type - set it to Source Control Type 

# Enter the username & password for the Bitbucket service account

#Enter the AWX server's Private Key in the SCM Private Key Window

#Save

```


Step 3: Create a New Project
-----------------------------------------

``` {.wp-block-code}
#Select Projects

#Add

#Fill out Name

#Source Control Type - Select Git


#Source Control URL - Enter the URL for the Bitbucket Inventory Repo that is being used "https://bitbucket.uconn.edu/scm/awx-its/ansible-awx-dynamic-inventories.git"

#Source Control Credential - Enter name of the newly created Bitbucker Source Control credentials created in step 2

#Save
```




Step 4: Create Active Directory Inventory
-----------------------------------------

``` {.wp-block-code}
#Select Inventories

#Add

#Fill out Name

#Save
```

Step 5: Create a Source For Your Inventory
--------------------------------------------------------------

``` {.wp-block-code}
#Select Inventories

#Click on newly added Inventory's name

#Select the Sources Option

#Add 

#Fill out Name

#Click source drop down select - Sourced from a project option

#Select the Inventory project you created in Step 3.

#In the Inventoryfile text box - select ldap.py

#Save
```

Step 6: Add a Source To Newly Added Active Directory Inventory
--------------------------------------------------------------

``` {.wp-block-code}
#Select Inventories

#Click on newly added Inventory's name

#Select the Sources Option

#Add newly created Source 

#Save
```


